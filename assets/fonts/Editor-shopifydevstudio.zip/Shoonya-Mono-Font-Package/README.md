# Shoonya Mono Typeface Suite (Complete 10-Style Family)

Created directly from high-resolution vector extraction of the master brand reference (`63F8CC34-86C7-451C-B331-CCA9FC341675.JPG`).

## 📁 Package Contents

### 1. Desktop Fonts (`Desktop-Fonts (TTF - Mac and Windows)`)
TrueType font files (.ttf) ready to install on macOS, Windows, Linux, and design software:
- `ShoonyaMono-Light.ttf` (300)
- `ShoonyaMono-Regular.ttf` (400 — Master Reference Match)
- `ShoonyaMono-Medium.ttf` (500)
- `ShoonyaMono-Bold.ttf` (700)
- `ShoonyaMono-Black.ttf` (900)
- `ShoonyaMono-LightItalic.ttf` (300 Italic)
- `ShoonyaMono-Italic.ttf` (400 Italic)
- `ShoonyaMono-MediumItalic.ttf` (500 Italic)
- `ShoonyaMono-BoldItalic.ttf` (700 Italic)
- `ShoonyaMono-BlackItalic.ttf` (900 Italic)

### 2. Web Fonts (`Web-Fonts (WOFF2 and WOFF - Web Apps)`)
Ultra-lightweight modern web font formats with full sub-pixel hinting:
- `.woff2` (Next-gen format with superior compression, for modern browsers)
- `.woff` (Legacy web format for wide cross-browser support)

### 3. Stylesheet (`shoonya-mono.css`)
Ready-to-use CSS file with `@font-face` declarations for all 10 styles.

---

## 💻 How to Install on Desktop

### macOS:
1. Open the `Desktop-Fonts (TTF - Mac and Windows)` folder.
2. Select all `.ttf` files, right-click, and choose **Open with Font Book**.
3. Click **Install Font**.
4. The font will now appear as **Shoonya Mono** with 10 styles across Figma, Adobe Creative Cloud, Keynote, Word, etc.

### Windows:
1. Open the `Desktop-Fonts (TTF - Mac and Windows)` folder.
2. Select all `.ttf` files, right-click, and select **Install for all users** (or **Install**).

---

## 🌐 How to Use in Web Applications

1. Copy the `Web-Fonts` and `Desktop-Fonts` folders and `shoonya-mono.css` into your web project.
2. In your HTML `<head>`:
```html
<link rel="stylesheet" href="path/to/shoonya-mono.css">
```
3. In your CSS:
```css
/* Normal (Upright) */
.brand-title {
    font-family: 'Shoonya Mono', monospace;
    font-weight: 400;
    font-style: normal;
}

/* Italic */
.brand-subtitle {
    font-family: 'Shoonya Mono', monospace;
    font-weight: 400;
    font-style: italic;
}

/* Bold Italic */
.brand-emphasis {
    font-family: 'Shoonya Mono', monospace;
    font-weight: 700;
    font-style: italic;
}
```

---
© Shoonya Tribe Brand Identity System. All rights reserved.
